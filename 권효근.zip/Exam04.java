package com.yedam.jeshi;

public class Exam04 {
	public static void main(String[] args) {

		int i = 2;
		int j = 2;
		for (i = 2; i < 10; i++) {
			System.out.println(i);

			for (j = 1; j < 10; j++) {
				System.out.printf("%d X %d = %d\n", i, j, i * j);

			}
		}
	}
}
