package com.yedam.jeshi;

import java.util.Scanner;

public class Exam05 {
	public static void main(String[] args) {
		boolean run = true;
		Scanner sc = new Scanner(System.in);

		int[] scores = null;
		int studentNum = 0;

		while (run) {
			System.out.println("=== 1.학생수 | 2.점수 | 3.점수리스트 | 4.점수 분석 | 5.종료 ===");
			System.out.println("선택 > ");
			int selectNo = Integer.parseInt(sc.nextLine());

			switch (selectNo) {
			case 1:
				System.out.println("학생수 > ");
				studentNum = Integer.parseInt(sc.nextLine());
				scores = new int[studentNum];
				break;
			case 2:
				for (int i = 0; i < scores.length; i++) {
					System.out.println("점수 > ");
					int score = Integer.parseInt(sc.nextLine());
					scores[i] = score;
				}
				break;
			case 3:
				for (int i = 0; i < scores.length; i++) {
					System.out.printf("점수 : %d\n", scores[i]);
				}
				break;
			case 4:
				int max = scores[0];
				int min = scores[0];
				for (int i = 0; i < scores.length; i++) {
					if (max < scores[i]) {
						max = scores[i];
					}
					for (int j = 0; j < scores.length; j++) {
						if (min > scores[j]) {
							min = scores[j];
						}
					}
				}
				System.out.println("최고점 : " + max + "최저점 : " + min);
				break;
			case 5:
				run = false;
				break;
			default:
				System.out.println("입력번호를 확인하세요");

			}
		}
	}
}
