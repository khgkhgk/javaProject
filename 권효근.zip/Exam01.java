package com.yedam.jeshi;

public class Exam01 {
	public static void main(String[] args) {

		double a = 1.2;
		float b = 0.9f;

		double totala = a + b;
		System.out.println((int) totala);

		double totalb = a - b;
		System.out.println((int) totalb);

		double totalc = a * b;
		System.out.println((int) totalc);

		double totald = a / b;
		System.out.println((int) totald);

	}
}
