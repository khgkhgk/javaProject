package com.yedam.jeshi;

public class Exam03 {
	public static void main(String[] args) {
		int age = 8;
		int charge;

		if (age < 8) {
			System.out.println("1000원");
		} else if (age < 14) {
			System.out.println("2000원");
		} else if (age < 20) {
			System.out.println("2500원");
		} else {
			System.out.println("3000원");
		}

	}
}
